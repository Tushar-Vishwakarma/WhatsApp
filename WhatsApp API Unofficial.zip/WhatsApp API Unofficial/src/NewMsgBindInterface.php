<!--Creator: Tushar Vishwakarma -->

<?php

interface NewMsgBindInterface
{
    public function process(ProtocolNode $node);
}
