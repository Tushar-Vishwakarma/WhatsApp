<!--Creator: Tushar Vishwakarma -->

<?php

class StaleKeyExchangeException extends Exception
{
}
