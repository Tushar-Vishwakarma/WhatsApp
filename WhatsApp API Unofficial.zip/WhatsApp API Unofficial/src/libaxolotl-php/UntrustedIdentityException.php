<!--Creator: Tushar Vishwakarma -->

<?php

class UntrustedIdentityException extends Exception
{
}
